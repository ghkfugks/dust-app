# dust-app


 ## 🌆😷 서대문구 미세먼지에 대한 앱을 만들었습니다.
 
 ### 데이터 제공 사이트 
 #### 공공 데이터 포털 : https://www.data.go.kr/
 
 
 
##### 매핑 설정 방법


![dust](https://user-images.githubusercontent.com/105832380/172528540-67567e56-faa0-4ba0-8b40-1537857f9b38.png)

- 유저가 원하는 날짜와 시간을 입력
- 
![dust1](https://user-images.githubusercontent.com/105832380/172529237-38320c3c-cafb-4d9c-847b-425d749205a7.png)

- 유저의 데이터값 출력
- 
![dust3](https://user-images.githubusercontent.com/105832380/172530665-a4afbb51-8547-463d-a0a1-5de64da3f10a.png)

- 유저의 데이터값 맵에 출력


### 참고자료 

- ⭐️ **아이콘 사용법**: https://medium.com/codex/create-a-multi-page-app-with-the-new-streamlit-option-menu-component-3e3edaf7e7ad

- 🌏 **foiluim 사용법** : https://teddylee777.github.io/visualization/folium




